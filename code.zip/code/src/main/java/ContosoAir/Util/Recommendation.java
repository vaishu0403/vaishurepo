package ContosoAir.Util;

public class Recommendation {
    public String imageUrl;
    public String description;

    public Recommendation(String imageUrl, String description) {
        this.imageUrl = imageUrl;
        this.description = description;
    }

    public Recommendation() {
    }
}
